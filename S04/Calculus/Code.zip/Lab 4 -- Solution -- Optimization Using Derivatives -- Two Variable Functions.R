# 1. Define and plot f(x,y) = x^2 + x*y + y^2 + y for x and y between -10 and 10
f <- function(x,y) x^2 + x*y + y^2 + y

library(rgl)
plot3d(f, xlim = c(-10,10), ylim = c(-10,10))



# 2. Find f.x, f.y, f.xx, f.yy, and f.xy. Write the closed form expressions for each.
library(Deriv)
f.x <- Deriv(f, x = 'x')
f.x # 2x + y

f.y <- Deriv(f, x = 'y')
f.y # 2y + x + 1

f.xx <- Deriv(f.x, x = 'x')
f.xx # 2

f.yy <- Deriv(f.y, x = 'y')
f.yy # 2

f.xy <- Deriv(f.x, x = 'y')
f.xy # 1



# 3. The critical point is at (1/3, -2/3). Verify analytically that f.x and f.y equal 0 here.
f.x(x=1/3, y=-2/3)
f.y(x=1/3, y=-2/3)

## might want to verify critical point
library(rootSolve)

funs <- function(x) c(f1 = 2*x[1] + x[2],
                      f2 = x[1] + 2*x[2] + 1)
multiroot(funs, start = c(0,0))






# 4. Verify the critical point satisfies the conditions of the Second Der. Test for being a min.
D <- f.xx(c(1/3,-2/3))*f.yy(c(1/3,-2/3)) - f.xy(c(1/3,-2/3))^2
D

f.xx(c(1/3,-2/3))

## D > 0 and f.xx > 0, so it is a local min






